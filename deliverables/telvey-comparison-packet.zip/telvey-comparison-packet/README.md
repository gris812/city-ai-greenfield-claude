# Telvey comparison packet

Date: 2026-10-04. Working brand: **Telvey** (not legally cleared; domains unregistered). Product status: **zero real users,
zero real-device runs, zero live-provider runs.** Every number in the report carries a label (MEASURED-tests, -replay,
-harness, -e2e; ESTIMATED; ASSUMED or HYPOTHESIS; DERIVED; NOT YET MEASURED or NOT RUN).

## Public URLs

| Surface | URL |
|---|---|
| Website | **Not deployed. Blocked on VPS and domain credentials.** |
| WebApp | **Not deployed. Blocked on VPS and domain credentials.** |
| Admin console | **Not deployed. Blocked on VPS and domain credentials.** |
| Native test builds (Android APK, iOS) | **No build exists.** Blocked on Expo, Apple Developer and Android SDK access. Instructions: `docs/MOBILE.md` section 5 |

No URL is given because none exists. The WebApp, website and admin console run locally from the repository in offline demo mode.

## Contents

| Path | What it is |
|---|---|
| `INVESTOR_REPORT.pdf` | The investor report (read this first) |
| `report-source/` | Editable Markdown source, the build script (Markdown to HTML to PDF with Chromium), the number-check script, and the scripts that made the figures, screenshots and demo |
| `REPORT_REVIEW.md` | Adversarial review of the report: unsupported claims found, inconsistencies, weak differentiation, missing investor questions, what was changed |
| `screenshots/` | The report's UX, web and admin captures (offline demo mode, simulated location, template prose, no voice, schematic map; admin images are DEMO DATA) and `INDEX.md` mapping them to the 16 template items. Item 16 (mobile admin) was not capturable and is not faked |
| `brand/` | Brand board, logo lockups, wordmark, mark, app icons, favicon, design tokens |
| `guides/` | Original Guides Ida and Emil: portraits, city-context scenes, avatars (SVG and PNG) |
| `figures/` | The 13 report figures as SVG and PNG: system context, modules, narrative pipeline, conversation state, provider routing, data and cache, surfaces, competitor matrix, TAM, SAM and SOM bridge, user flow, roadmap, acceptance status, free-tier economics |
| `charts/` | Five benchmark charts (cost per session, driver month, latency, replay timeline, query rate) |
| `data/benchmark/` | Acceptance results (JSON), per-scenario CSV, latency JSON and CSV, replay summary |
| `data/cost/` | Cost model JSON and CSVs (ESTIMATED list-price model) |
| `data/research/` | Market model, competitor research, provider pricing (retrieved 2026-09-27), domain checks (2026-09-27 UTC) |
| `docs/MOBILE.md`, `docs/DEPLOY.md` | Native build and device-test instructions; server deployment guide (never run on a real host) |
| `demo/telvey-web-demo.mp4` | 74-second screen recording of the offline demo (walk, interruption, resume, highway drive HUD). Same limits as the screenshots |
| `MANIFEST.json` | SHA-256 and size of every file |

## How to check the numbers

`python3 report-source/scripts/check-numbers.py` (run from the repository) asserts that the headline numbers in the report match
`data/benchmark/*.json`, `data/cost/cost_model.json` and `data/research/market.json`.
